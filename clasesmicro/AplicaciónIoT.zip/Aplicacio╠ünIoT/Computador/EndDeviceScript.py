from __future__ import division
import numpy
import serial, struct
import time
import sys
import os
import csv
import random

from firebase import firebase
from datetime import datetime

tiempoEnvioDatos = 10

urlDB = 'https://esp82-40f3b-default-rtdb.firebaseio.com'

# Firebase
def sendData(usuario, var1, var2, tiempo):
	data = {'Dato1': var1, 'Dato2': var2, 'EstampaTiempo': tiempo}
	fb = firebase.FirebaseApplication(urlDB, None)
	#result = fb.post('/usuario/',data)
	result = fb.patch('/' + usuario + '/', data)
	return result

def getData(usuario):
	fb = firebase.FirebaseApplication(urlDB, None)
	result = fb.get('/' + usuario + '/', None)
		
	#s1 = int(result.get('sensor1'))
	#s2 = int(result.get('sensor2'))
	#d1 = int(result.get('dato1'))
	
	return result

#####################################################

def readTime(tipo):

	timeStamp = time.strftime("%d %b %Y %H:%M:%S", time.localtime())

	if tipo == 0:
		now = datetime.now()
		timestamp = datetime.timestamp(now)

	return timeStamp
	
########Programa principal#############

if __name__ == "__main__":

    contadorDatos = 0;

    while True:
        
        # Envía datos hacia Firebase

        if contadorDatos >= tiempoEnvioDatos:
            contadorDatos = 0
            
            print(readTime(0))
            
            print("Envío de datos a Firebase")
            variable1 = random.random()*100
            variable1 = round(variable1, 3)
            variable2 = random.random()*100
            variable2 = round(variable2, 3)
            try:
                result = sendData('Computador', variable1, variable2, readTime(1))
                print('Datos enviados:', result)
            except:
                print("Error al enviar datos a Firebase")

            print("Recepción de datos desde Firebase")
            result = getData('ESP8266')
            print(result, end='\n\n')
		
        time.sleep(1) # delay del lazo de 1 segundo
        contadorDatos += 1
		
