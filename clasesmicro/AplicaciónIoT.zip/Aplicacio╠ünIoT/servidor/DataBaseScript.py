import time
import sqlite3
import os
import random

from firebase import firebase
from datetime import datetime

global Dato1, Dato2, EstampaTiempoComp
global Contador, Dato, EstampaTiempoESP, Sensor

urlDB = 'https://esp82-40f3b-default-rtdb.firebaseio.com'

dataBaseName = 'baseDatos.db'

tiempoMuestra = 15 #segundos

# Firebase

def sendData(usuario, config1, config2, tiempo):
	data = {'Config1': config1,
            'Config2': config2,
            'EstampaTiempo': tiempo
            }

	fb = firebase.FirebaseApplication(urlDB, None)
	#result = fb.post('/' + usuario + '/',data)
	result = fb.patch('/' + usuario + '/', data)
	return result

def getData(usuario):
    global Dato1, Dato2, EstampaTiempoComp
    global Contador, Dato, Sensor, EstampaTiempoESP

    fb = firebase.FirebaseApplication(urlDB, None)
    result = fb.get('/' + usuario + '/', None)

    if usuario == 'Computador':
        Dato1 = float(result.get('Dato1'))
        Dato2 = float(result.get('Dato2'))
        EstampaTiempoComp = result.get('EstampaTiempo')
    elif usuario == 'ESP8266':
        Contador = int(result.get('Contador'))
        Dato = float(result.get('Dato'))
        Sensor = float(result.get('Sensor'))
        EstampaTiempoESP = result.get('EstampaTiempo')

    return result
	
# Base de datos

def initDB():
    conn = sqlite3.connect(dataBaseName)
    c = conn.cursor()
    c.execute('''CREATE TABLE HistorialComputador (ID integer primary key, Ticks real, Dato1 real, Dato2 real)''')
    conn.commit() #guarda cambios

    c.execute('''CREATE TABLE HistorialESP8266 (ID integer primary key, Ticks real, Contador integer, Dato real, Sensor real)''')
    conn.commit() #save changes

    conn.close()

def addNewDataDBComp():
    global Dato1, Dato2, EstampaTiempoComp

    tTicks = time.time()

    conn = sqlite3.connect(dataBaseName)
    c = conn.cursor()
    c.execute('''INSERT INTO HistorialComputador (Ticks, Dato1, Dato2)\
    VALUES (?, ?, ?)''', (tTicks, Dato1, Dato2))
    conn.commit()

def addNewDataDBESP():

    global Contador, Dato, Sensor, EstampaTiempoESP

    tTicks = time.time()

    conn = sqlite3.connect(dataBaseName)
    c = conn.cursor()
    c.execute('''INSERT INTO HistorialESP8266 (Ticks, Contador, Dato, Sensor)\
    VALUES (?, ?, ?, ?)''', (tTicks, Contador, Dato, Sensor))
    conn.commit()

def readTime(tipo):

	timeStamp = time.strftime("%d %b %Y %H:%M:%S", time.localtime())

	if tipo == 0:
		now = datetime.now()
		timestamp = datetime.timestamp(now)

	return timeStamp

########Programa principal#############

if __name__ == "__main__":

    if os.path.isfile(dataBaseName) == False: #verifica si existe la base de datos
        initDB() #si no existe, se la crea
        print("Un nuevo archivo de base de datos ha sido creado")
    else:
        print("Un archivo de base de datos ha sido encontrado")

    while True:
        print()
        print(readTime(0))
        
        print("\nEnvío de datos hacia Firebase")
        config1 = random.random()
        config2 = random.random()
        
        try:
            result = sendData("Servidor", config1, config2, readTime(1))
            print('Datos enviados:', result)
        except:
            print("Error al enviar datos hacia Firebase")
        
        print("\nRecepción de datos desde Firebase")
        try:
            result = getData('Computador')
            print(result)
            result = getData('ESP8266')
            print(result)
            addNewDataDBComp()
            addNewDataDBESP()
        except:
            print("Error al recibir datos desde Firebase")

        time.sleep(tiempoMuestra)
